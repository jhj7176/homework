License 

Free Personal & Commercial Use but don�t redistribute or sell this PSD files, if you want to share this file please do not create direct download, please refer to my original page  behance 
https://www.behance.net/yopidesigner

you can change the font what do you want.
you can do anything because 100% editable.
168 buttons inculded
font used "open sans" https://www.google.com/fonts#UsePlace:use/Collection:Open+Sans

Best Regards

