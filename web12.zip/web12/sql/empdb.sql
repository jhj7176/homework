insert into emp (empno, ename, job, deptno, sal) values (1231, 'tester' ,'manager', 40, 1800)

select * from emp;

delete from emp where empno = 9999 and empno = 8271 and empno = 1231;